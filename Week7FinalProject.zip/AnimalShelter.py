"""
Created on Sun Mar 30 21:06:14 2024

@author: anthonyfillmo_snhu
"""

from pymongo import MongoClient
from bson.objectid import ObjectId

class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """

    def __init__(self, USER, PASS):
        # Initializing the MongoClient. This helps to 
        # access th,e MongoDB databases and collections.
        # This is hard-wired to use the aac database, the 
        # animals collection, and the aac user.
        # Definitions of the connection string variables are
        # unique to the individual Apporto environment.
        #
        # You must edit the connection variables below to reflect
        # your own instance of MongoDB!
        #
        # Connection Variables
        #
        #USER = 'aacuser'
        #PASS = 'aacpass'
        HOST = 'nv-desktop-services.apporto.com'
        PORT = 32239
        DB = 'AAC'
        COL = 'animals'
        #
        # Initialize Connection
        #
        self.client = MongoClient('mongodb://%s:%s@%s:%d' % (USER,PASS,HOST,PORT))
        self.database = self.client['%s' % (DB)]
        self.collection = self.database['%s' % (COL)]
        
    def create(self, data):
        """
        Inserts a single document into the MongoDB collection.

        :param data: Dictionary representing the document to be inserted. Must not be None.
        :return: True if the insert operation is successful, False otherwise. Prints an 
        error message if `data` is None or an exception occurs during insertion.
        
        This method facilitates the 'Create' operation in CRUD, inserting a document into
        the specified collection within the database.
        """
        if data is not None:
            # protect db insert call
            try:
               self.database.animals.insert_one(data)
               return True 
                
            
            except Exception as e:
                print(f"An error occurred: {e}")
                return False

        else:
            print("Nothing to save, because data parameter is empty")
            return False

    def read(self, query):
        """
        Retrieves documents matching the query from the MongoDB collection.

        :param query: Dictionary of the criteria used to select documents. Must not be None.
        :return: A list of documents that match the query criteria. Returns an empty list if 
        no documents match or if an exception occurs during the query execution.

        Implements the 'Read' functionality of CRUD, performing a query against the collection
        to fetch and return the desired documents.
        """
        if query is not None:
            # protect db collection query
            try:
                documents = self.collection.find(query)
                return list(documents) # return a list of documents someone can iterate on
            except Exception as e:
                print(f"An error occurred: {e}")
                return []
            
        else:
            print("Query cannot be empty")
            return []
        
    def read_rescue_type(self, rescue_type):
        """
        Retrieves documents based on the rescue type.

        :param rescue_type: String to specify the rescue type.
        :return: A list of documents that match the rescue type criteria.
        """
        query = {}
        if rescue_type == "Water Rescue":
            query = {"breed": {"$in": ["Labrador Retriever Mix", "Chesapeake Bay Retriever", "Newfoundland"]}}
        elif rescue_type == "Mountain or Wilderness Rescue":
            query = {"breed": {"$in": ["German Shepherd", "Alaskan Malamute", "Old English Sheepdog", "Siberian Husky", "Rottweiler"]}}
        elif rescue_type == "Disaster or Individual Tracking":
            query = {"breed": {"$in": ["Doberman Pinscher", "German Shepherd", "Golden Retriever", "Bloodhound", "Rottweiler"]}}

        try:
            documents = self.collection.find(query)
            return list(documents)
        except Exception as e:
            print(f"An error occurred: {e}")
            return []


    def update(self, query, update_data, many=False):
        """
        Update document(s) based on a query.
        :param query: Dictionary of key/value pairs to find the document(s).
        :param update_data: Dictionary of key/value pairs to update in the found document(s).
        :param many: Boolean, if True, update_many() is used, else update_one().
        :return: The number of documents updated.
        """
        if query is None or update_data is None:
            print("Query and/or update data cannot be empty")
            return 0
        try:
            if many:
                result = self.database.animals.update_many(query, {'$set': update_data})
            else:
                result = self.database.animals.update_one(query, {'$set': update_data})
            return result.modified_count
        except Exception as e:
            print(f"An error occurred: {e}")
            return 0
    
    def delete(self, query, many=False):
        """
        Delete document(s) based on a query.
        :param query: Dictionary of key/value pairs to find the document(s).
        :param many: Boolean, if True, delete_many() is used, else delete_one().
        :return: The number of documents deleted.
        """
        if query is None:
            print("Query cannot be empty")
            return 0
        try:
            if many:
                result = self.database.animals.delete_many(query)
            else:
                result = self.database.animals.delete_one(query)
            return result.deleted_count
        except Exception as e:
            print(f"An error occurred: {e}")
            return 0
